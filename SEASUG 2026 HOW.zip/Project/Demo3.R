

# Sample Data -------------------------------------------------------------

# Create sample data
cls <- read.table(header = TRUE, text = '
Name   Sex Age Height Weight  Group
Alfred   M  14   69.0  112.5      A
Alice    F  13   56.5   84.0      A
Barbara  F  13   65.3   98.0      A
Carol    F  14   62.8  102.5      A
Henry    M  14   63.5  102.5      A
James    M  12   57.3   83.0      A
Jane     F  12   59.8   84.5      A
Janet    F  15   62.5  112.5      A
Jeffrey  M  13   62.5   84.0      A
John     M  12   59.0   99.5      B
Joyce    F  11   51.3   50.5      B
Judy     F  14   64.3   90.0      B
Louise   F  12   56.3   77.0      B
Mary     F  15   66.5  112.0      B
Philip   M  16   72.0  150.0      B
Robert   M  12   64.8  128.0      B
Ronald   M  15   67.0  133.0      B
Thomas   M  11   57.5   85.0      B
William  M  15   66.5  112.0      B')

t <- paste0("Lorem ipsum dolor sit amet, consectetur adipiscing elit, ",
            "sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ",
            "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris ",
            "nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in ",
            "reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla ",
            "pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa ",
            "qui officia deserunt mollit anim id est laborum.")

dat <- read.table(header = TRUE, text = '
VAR      LABEL            A             B
Age          N            9            10
Age    MEANSTD  "13.3 (1.00)" "13.3 (1.89)"
Age     MEDIAN           13            13
Age       Q1Q3    13.0-14.0     12.0-15.0
Age     MINMAX        12-15         11-16
Height       N            9            10
Height MEANSTD  "62.1 (3.88)" "62.5 (6.26)"
Height  MEDIAN        62.50         64.55
Height    Q1Q3    59.8-63.5     57.5-66.5
Height  MINMAX    56.5-69.0     51.3-72.0
Weight       N            9            10
Weight MEANSTD "95.9 (12.36)" "103.7 (29.49)"
Weight  MEDIAN        98.00        105.75
Weight    Q1Q3   84.0-102.5    85.0-128.0
Weight  MINMAX   83.0-112.5    50.5-150.0
Sex          N            9            10
Sex          F    "5 (55.6%)"  "4 (40.0%)"
Sex          M    "4 (44.4%)"  "6 (60.0%)"')

# Create Text -------------------------------------------------------------



# Create table
txt <- create_text(t, borders = c("top", "bottom"), width = 5)  |>
  titles("Text 1.0", "Text Content", bold = TRUE)


# Create report and add content
rpt <- create_report("./report/example6", output_type = "DOCX",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(txt) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write out report
res <- write_report(rpt)

file.show(res$path)



# Create Plot -------------------------------------------------------------



library(ggplot2)

# Calculate statistics
agemn <- mean(cls$Age)
agesd <- sd(cls$Age)

# Create ggplot object
p <- ggplot(cls, aes(Age)) +
  geom_histogram(aes(y = after_stat(density)), bins = 6,
                 color="darkblue", fill="#CAD5E5",
                 show.legend = FALSE) +
  theme_light() +
  stat_function(fun = dnorm,
                args = list(mean = agemn,
                            sd = agesd),
                aes(col = "#1b98e0"),
                linewidth = 1) +
  geom_density(adjust = 1.75, linewidth = 1, aes(col = "red"),
               show.legend = FALSE) +
  geom_vline(aes(xintercept=agemn),
             color="darkgray", linetype="dashed", linewidth=1) +

  scale_color_manual("Legend", values = c("#1b98e0", "red"),
                     labels = c("normal", "kernel")) +
  theme(text = element_text(size = 7),
        panel.border = element_rect(colour = "black", fill=NA,
                                    linewidth=1))


# Create plot content
plt <- create_plot(p, height = 4, width = 7) |>
  titles("Figure 1.0", "Age Distribution",
         bold = TRUE)

# Create report object
rpt <- create_report("./report/figure1", output_type = "DOCX",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(plt) |>

  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write report to file
res <- write_report(rpt)

file.show(res$path)


# Combined Contents -------------------------------------------------------



# Vector lookup for VAR
varfmt <- c(Age = "Age (yrs)",
            Height = "Height (inches)",
            Weight = "Weight (lbs)",
            Sex = "Biological Sex")

# Vector lookup for LABEL
labelfmt <- c(N = "n", MEANSTD = "Mean (STD)", MEDIAN = "Median",
              Q1Q3 = "Q1-Q3", MINMAX = "Min-Max",
              "F" = "Female", M = "Male")

# Create table
tbl <- create_table(dat, borders = c("top", "bottom"),
                    first_row_blank = TRUE) |>
  titles("Table 1.0", "Nested Stub", bold = TRUE) |>
  column_defaults(width = 1, align = "center") |>
  stub(c(VAR, LABEL), width = 1.5) |>
  define(VAR, label = "Variable", blank_after = TRUE,
         format = varfmt, label_row = TRUE) |>
  define(LABEL, label = "", align = "left", format = labelfmt, indent = .25) |>
  define(A, label = "Group A", n = 9) |>
  define(B, label = "Group B", n = 10)


# Create report and add content
rpt <- create_report("./report/example4", output_type = "RTF",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  add_content(plt, page_break = FALSE) |>
  add_content(txt) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write out report
res <- write_report(rpt)

file.show(res$path)


