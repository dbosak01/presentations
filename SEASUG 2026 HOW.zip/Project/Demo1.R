


# Sample data -------------------------------------------------------------

dat <- read.table(header = TRUE, text = '
VAR      LABEL            A             B
Age          N            9            10
Age    MEANSTD  "13.3 (1.00)" "13.3 (1.89)"
Age     MEDIAN           13            13
Age       Q1Q3    13.0-14.0     12.0-15.0
Age     MINMAX        12-15         11-16
Height       N            9            10
Height MEANSTD  "62.1 (3.88)" "62.5 (6.26)"
Height  MEDIAN        62.50         64.55
Height    Q1Q3    59.8-63.5     57.5-66.5
Height  MINMAX    56.5-69.0     51.3-72.0
Weight       N            9            10
Weight MEANSTD "95.9 (12.36)" "103.7 (29.49)"
Weight  MEDIAN        98.00        105.75
Weight    Q1Q3   84.0-102.5    85.0-128.0
Weight  MINMAX   83.0-112.5    50.5-150.0
Sex          N            9            10
Sex          F    "5 (55.6%)"  "4 (40.0%)"
Sex          M    "4 (44.4%)"  "6 (60.0%)"')



# Minimal Example --------------------------------------------------------


library(reporter)

# 1. Create table
tbl <- create_table(dat)

# 2. Create the report
rpt <- create_report("./report/example1") |>
  add_content(tbl)

# 3. Write the report
res <- write_report(rpt)

file.show(res$path)

# Output Types --------------------------------------------------------


library(reporter)

# Create table
tbl <- create_table(dat)

# Create the report
rpt <- create_report("./report/example1",
                     font = "Courier",
                     output_type = "DOCX") |>
  add_content(tbl)

# Write the report
res <- write_report(rpt)

file.show(res$path)


# Titles and Footnotes -----------------------------------------------------


library(reporter)

# Create table
tbl <- create_table(dat) |>
  titles("Listing 1.0", "Titles and Footnotes") |>
  footnotes("* SESUG, 2026")

# Create the report
rpt <- create_report("./report/example1",
                     font = "Courier",
                     output_type = "DOCX") |>
  add_content(tbl)

# Write the report
res <- write_report(rpt)

file.show(res$path)



# Page Headers/Footers ----------------------------------------------------


# Create table
tbl <- create_table(dat) |>
  titles("Listing 1.0", "Page Headers and Footers")

# Create the report
rpt <- create_report("./report/example2", output_type = "DOCX",
                     font = "Arial") |>
  page_header("Sponsor: My Company", "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026", footer = TRUE) |>
  page_footer(Sys.time(), "Confidential", "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)


# Borders -----------------------------------------------------------------


# Create table
tbl <- create_table(dat, borders = c("top", "bottom"),
                    first_row_blank = TRUE) |>
  titles("Listing 1.0", "Table with Borders", bold = TRUE)

# Create the report
rpt <- create_report("./report/example3", output_type = "DOCX",
                     font = "Arial") |>
  page_header("Sponsor: My Company", "Study: Students") |>
  add_content(tbl)  |>
  footnotes("* SESUG, 2026", footer = TRUE, blank_row = "none") |>
  page_footer(Sys.time(), "Confidential", "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)



# Column Definitions ------------------------------------------------------


# Create table
tbl <- create_table(dat, borders = c("top", "bottom"),
                    first_row_blank = TRUE) |>
  titles("Table 1.0", "Column Definitions", bold = TRUE) |>
  define(VAR, label = "Variable", blank_after = TRUE, dedupe = TRUE,
         width = 1.5, align = "left") |>
  define(LABEL, label = "", align = "left", width = 1) |>
  define(A, label = "Group A", n = 9, width = 1) |>
  define(B, label = "Group B", n = 10, width = 1)


# Create report and add content
rpt <- create_report("./report/example4", output_type = "DOCX",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write out report
res <- write_report(rpt)

file.show(res$path)

# Formatting ------------------------------------------------------


# Vector lookup for VAR
varfmt <- c(Age = "Age (yrs)",
            Height = "Height (inches)",
            Weight = "Weight (lbs)",
            Sex = "Biological Sex")

# Vector lookup for LABEL
labelfmt <- c(N = "n", MEANSTD = "Mean (STD)", MEDIAN = "Median",
              Q1Q3 = "Q1-Q3", MINMAX = "Min-Max",
              "F" = "Female", M = "Male")

# Create table
tbl <- create_table(dat, borders = c("top", "bottom"),
                    first_row_blank = TRUE) |>
  titles("Table 1.0", "Column Definitions", bold = TRUE) |>
  column_defaults(width = 1, align = "center") |>
  define(VAR, label = "Variable", blank_after = TRUE, dedupe = TRUE,
         format = varfmt, width = 1.5, align = "left") |>
  define(LABEL, label = "", align = "left", format = labelfmt) |>
  define(A, label = "Group A", n = 9) |>
  define(B, label = "Group B", n = 10)


# Create report and add content
rpt <- create_report("./report/example4", output_type = "DOCX",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write out report
res <- write_report(rpt)

file.show(res$path)


# Nested Stub ------------------------------------------------------


# Vector lookup for VAR
varfmt <- c(Age = "Age (yrs)",
            Height = "Height (inches)",
            Weight = "Weight (lbs)",
            Sex = "Biological Sex")

# Vector lookup for LABEL
labelfmt <- c(N = "n", MEANSTD = "Mean (STD)", MEDIAN = "Median",
              Q1Q3 = "Q1-Q3", MINMAX = "Min-Max",
              "F" = "Female", M = "Male")

# Create table
tbl <- create_table(dat, borders = c("top", "bottom"),
                    first_row_blank = TRUE) |>
  titles("Table 1.0", "Nested Stub", bold = TRUE) |>
  column_defaults(width = 1, align = "center") |>
  stub(c(VAR, LABEL), width = 1.5) |>
  define(VAR, label = "Variable", blank_after = TRUE,
         format = varfmt, label_row = TRUE) |>
  define(LABEL, label = "", align = "left", format = labelfmt, indent = .25) |>
  define(A, label = "Group A", n = 9) |>
  define(B, label = "Group B", n = 10)


# Create report and add content
rpt <- create_report("./report/example4", output_type = "DOCX",
                     font = "Arial") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write out report
res <- write_report(rpt)

file.show(res$path)
