
library(sassy)


libname(data, "./data", "csv")


# Basic Listing --------------------------------------------------------



# Create table
tbl <- create_table(data$DM) |>
  titles("Table 1.0", "Demographics Listing",
         bold = TRUE, font_size = 11)

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  add_content(tbl)

# Write the report
res <- write_report(rpt) |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

file.show(res$path)


# Control Page Wrapping --------------------------------------------------



# Create table
tbl <- create_table(data$DM) |>
  titles("Table 1.0", "Page Wrapping",
         bold = TRUE, font_size = 11) |>
  define(USUBJID, id_var = TRUE) |>
  define(RACE, page_wrap = TRUE) |>
  define(ARM, page_wrap = TRUE)

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)


# Control Page Breaking --------------------------------------------------


# Create table
tbl <- create_table(data$DM) |>
  titles("Table 1.0", "Page Breaking",
         bold = TRUE, font_size = 11) |>
  define(USUBJID, id_var = TRUE) |>
  define(RACE, page_wrap = TRUE) |>
  define(ARM, page_wrap = TRUE) |>
  define(SITEID, page_break = TRUE)

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)


# Group and Subset --------------------------------------------------


# Create table
tbl <- create_table(data$DM, show_cols = c("USUBJID", "SUBJID", "SITEID",
                                           "BRTHDTC", "AGE", "AGEU",	"SEX")) |>
  titles("Table 1.0", "Group and Subset",
         bold = TRUE, font_size = 11) |>
  define(USUBJID, id_var = TRUE) |>
  define(SITEID, blank_after = TRUE, group_cohesion = TRUE,
         break_label = "(Continued)")

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)



# Spanning Header --------------------------------------------------


# Create table
tbl <- create_table(data$DM, show_cols = c("USUBJID", "SUBJID", "SITEID",
                                           "BRTHDTC", "AGE", "AGEU",	"SEX")) |>
  titles("Table 1.0", "Spanning Header",
         bold = TRUE, font_size = 11) |>
  spanning_header(from = "BRTHDTC", to ="SEX", label = "Demographics") |>
  define(USUBJID, id_var = TRUE) |>
  define(SITEID, blank_after = TRUE, group_cohesion = TRUE,
         break_label = "(Continued)")

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)


# Cell Style --------------------------------------------------

dat <- data$DM
dat$ind1 <- ifelse(dat$AGE <= 30, TRUE, FALSE)
dat$ind2 <- ifelse(dat$AGE >= 75, TRUE, FALSE)

# Create table
tbl <- create_table(dat, show_cols = c("USUBJID", "SUBJID", "SITEID",
                                           "BRTHDTC", "AGE", "AGEU",	"SEX", "ind1", "ind2")) |>
  titles("Table 1.0", "Cell Style",
         bold = TRUE, font_size = 11) |>
  define(USUBJID, id_var = TRUE) |>
  define(SITEID, blank_after = TRUE, group_cohesion = TRUE,
         break_label = "(Continued)") |>
  define(AGE, style = list(cell_style(cell_color = "green", font_color = "white",
                                      borders = "all", indicator = "ind1"),
                           cell_style(cell_color = "red", font_color = "white",
                                      borders = "all", indicator = "ind2"))) |>
  define(c(ind1, ind2), visible = FALSE)

# Create the report
rpt <- create_report("./report/example5",
                     font = "Arial",
                     output_type = "DOCX") |>
  page_header(left = "Sponsor: My Company", right = "Study: Students") |>
  add_content(tbl) |>
  footnotes("* SESUG, 2026") |>
  page_footer(left = Sys.time(),
              center = "Confidential",
              right = "Page [pg] of [tpg]")

# Write the report
res <- write_report(rpt)

file.show(res$path)


